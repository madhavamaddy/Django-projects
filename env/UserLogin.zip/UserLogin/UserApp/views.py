# accounts/views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from .models import CustomUser,Contact
from .decorators import login_required

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        if username and email and password:
            if not CustomUser.objects.filter(username=username).exists():
                if not CustomUser.objects.filter(email=email).exists():
                    hashed_password = make_password(password)
                    CustomUser.objects.create(username=username, email=email, password=hashed_password)
                    messages.success(request, 'Registration successful.')
                    return redirect('login')
                else:
                    messages.error(request, 'Email already exists.')
            else:
                messages.error(request, 'Username already exists.')
        else:
            messages.error(request, 'All fields are required.')
    return render(request, 'register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username and password:
            try:
                user = CustomUser.objects.get(username=username)
                if check_password(password, user.password):
                    request.session['user_id'] = user.id
                    messages.success(request, 'Login successful.')
                    return redirect('home')  # Replace 'home' with the name of your homepage URL
                else:
                    messages.error(request, 'Invalid credentials.')
            except CustomUser.DoesNotExist:
                messages.error(request, 'User does not exist.')
        else:
            messages.error(request, 'Both username and password are required.')
    return render(request, 'login.html')

@login_required
def logout(request):
    request.session.flush()  # This will remove all session data
    messages.success(request, 'Logged out successfully.')
    return redirect('navbar')

@login_required
def home(request):
    user_id = request.session.get('user_id')
    if user_id:
        user = CustomUser.objects.get(id=user_id)
        context = {'is_authenticated': True, 'user': user}
    else:
        context = {'is_authenticated': False}
    return render(request, 'dashboard.html', context)

@login_required
def movies(request):
    return render(request,'movies.html')

@login_required
def contact(request):
    data = Contact.objects.all()
    return render(request,'contact.html',{'datas':data})


def navbar(request):
    return render(request,'nav.html')